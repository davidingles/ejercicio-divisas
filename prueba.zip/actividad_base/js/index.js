/*
Dólares USA - 1.06
Libras esterlinas - 0.87
Pesos argentinos - 370.22
Pesos colombianos - 4510.51
Pesos mexicanos - 19.33
*/
/*
const CAMBIOS=[
    {moneda:"Dólares USA",elCambio:1.06},
    {moneda:"Libras esterlinas",elCambio:0.87},
    {moneda:"Pesos argentinos",elCambio:370.22},
    {moneda:"Pesos colombianos",elCambio:4510.51},
    {moneda:"Pesos mexicanos",elCambio:19.33},
]
*/